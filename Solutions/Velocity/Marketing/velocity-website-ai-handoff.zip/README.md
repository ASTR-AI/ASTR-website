# Velocity website AI handoff

Start with docs/marketing/velocity-website-ai-prompt.md. Read docs/superpowers/plans/2026-10-25-velocity-website-handoff.md and docs/marketing/astr-pharmacy-product-story.md together. Preserve the folder structure for document links. Inspect the current ASTR AI website and capture fresh references in the destination project. Actual Velocity product screenshots must still be supplied with demo data. This package contains a plan and content, not a built or published page.
